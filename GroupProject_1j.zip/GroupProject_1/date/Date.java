/**
 * This course project is copyright of CyberTek ©CyberTek[2017]. All rights reserved. 
 * Any redistribution or reproduction of part or all of the contents in any form is 
 * prohibited without the express consent of CyberTek.
 */

package date;

import static org.junit.Assert.assertEquals;

import java.util.Calendar;

public class Date implements Comparable<Date> {

	private static final int[] DAYS = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	protected final int month;
	protected final int day;
	protected final int year;

	/*
	 * Initialized a new date from the month, day and year.
	 * 
	 * @param month the month (between 1 and 12)
	 * 
	 * @param day the day (between 1 and 28-31, depending on the month)
	 * 
	 * @param year the year
	 * 
	 */

	public Date(int month, int day, int year) {
		if (!isValid(month, day, year)) {
			System.out.println("Invalid Date");
			throw new IllegalArgumentException();
		}
		this.year = year;
		this.month = month;
		this.day = day;
	}

	/*
	 * @return month of that month
	 */
	public int getMonth() {
		return this.month;
	}

	/*
	 * @return day of that day
	 */
	public int getDay() {
		return this.day;
	}

	/*
	 * @return year of that year
	 */
	public int getYear() {
		return this.year;
	}

	/**
	 * This method checks if a given date is a valid calendar date
	 * 
	 * @param m
	 *            month
	 * @param d
	 *            day
	 * @param y
	 *            year. (A year is no less than 1900, and no greater than 2100)
	 * @return true if the given date is a valid calendar date. false otherwise
	 */
	public static boolean isValid(int m, int d, int y) {
		// TO DO
		// if (d < 1 || d > DAYS[m]) { <---we can do like this as well
		// return false;
		// }

		if (m < 1 || m > 12) {
			return false;
		}
		if (y < 1900 || y > 2100) {
			return false;
		}
		if (d < 1 || d > 31) {
			return false;
		}
		if (((m == 2) && (DAYS[2] != d)) && isLeapYear(y)) {
			return true;

		}
		if (!(d == DAYS[m])) {
			return true;
		}

		return true;

	}

	/**
	 * @param year
	 * @return true if the given year is a leap year. false otherwise.
	 */
	public static boolean isLeapYear(int year) {
		// TO DO
		// if(year%4 = 0 && year % 100 = 0 )
		// if((year % 4 == 0) && (year % 100 != 0) || (year % 400 == 0)) {
		//
		// }
		if (year % 400 == 0) {
			return true;
		}
		if (year % 100 == 0) {
			return false;
		}
		if (year % 4 == 0) {
			return true;
		}

		return false;
	}

	/**
	 * Compare this date to that day.
	 * 
	 * @return {a negative integer or zero or a positive integer}, depending on
	 *         whether this date is {before, equal to, after} that date
	 */

	public int compareTo(Date date1) {
		// TO DO
		// if classDate is less then date1 return -1
		// if classDate is greater then date1 return 1
		// if classDate is equal to date1 return 0
		if (this.year < date1.year)
			return -1;
		if (this.year > date1.year)
			return 1;
		if (this.month < date1.month)
			return -1;
		if (this.month > date1.month)
			return 1;
		if (this.day < date1.day)
			return -1;
		if (this.day < date1.day)
			return 1;

		// if(this.day == date1.day && this.day > date1.day && this.day < date1.day)
		// this.year!=date1.year
		// this.month date1.month

		return 0;
	}

	/**
	 * Return a string representation of this date.
	 * 
	 * @return the string representation in the format MM/DD/YYYY
	 */
	public String toString() {
		// TO DO

		return month + "/" + day + "/" + year;

	}

	/**
	 * 
	 * @return the word representation of the date. Example: (new
	 *         Date(12,1,2017)).dateToWords() returns "December One Two Thousand
	 *         Seventeen"
	 */
	public String dateToWords() {
		String[] monthWords = { "January", "February", "March", "April", "May", "June", "July", "August", "September",
				"October", "November", "December" };
		String[] numbersLessThanTen = { "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten" };
		String[] numbersBetweenTenAndTwenty = { "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
				"Seventeen", "Eighteen", "Nineteen" };
		String[] multiplesOfTen = { "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty",
				"Ninety" };
		String[] yearWords = { "Hundred", "Thousand" };

		// TO DO
		String monthInWords = "";
		String dayInWords = "";
		String yearInWords = "";
		// convert month
		monthInWords = monthWords[this.month - 1];
		// covert day
		if (day <= 10 && day > 0) {
			dayInWords = numbersLessThanTen[day - 1];
		}
		if (day > 10 && day <= 19) {
			dayInWords = numbersBetweenTenAndTwenty[day - 11];
		}
		if (day % 10 == 0) {
			dayInWords = multiplesOfTen[day / 10 - 1];
		}
		if (day > 20 && day < 30 || day == 31) {
			dayInWords = multiplesOfTen[day / 10 - 1] + "" + numbersLessThanTen[day % 10 - 1];
		}
		// convert year
		if (year == 1000) {
			yearInWords = numbersLessThanTen[year / 1000 - 1] + " " + yearWords[1];
		}
		String thousands = "";
		String hundreds = "";
		String tens = "";
		if (year > 1000) {
			thousands = numbersLessThanTen[year / 1000 - 1] + " " + yearWords[1];

			if ((year % 1000) / 100 != 0) {
				hundreds = numbersLessThanTen[(year % 1000) / 100 - 1] + " " + yearWords[0];
			}
			int reminder = ((year % 1000) % 100);
			if (reminder / 10 > 0) {
				if (reminder % 10 == 0) {
					tens = multiplesOfTen[reminder / 10 - 1];
				}
				if (reminder > 20) {
					tens = multiplesOfTen[reminder / 10 - 1] + " " + numbersLessThanTen[reminder % 10 - 1];
				}
				if (reminder < 10) {
					tens = numbersLessThanTen[reminder % 10 - 1];
				}
				if (reminder > 10 && reminder < 20) {
					tens = numbersBetweenTenAndTwenty[reminder % 10 - 1];
				}
			}
			yearInWords = thousands + " " + hundreds + " " + tens;
		}

		
		return monthInWords+" "+dayInWords+" "+yearInWords;
	}

	public int age() {
		Calendar cal = Calendar.getInstance();
		int d = cal.get(Calendar.DAY_OF_MONTH);
		int m = cal.get(Calendar.MONTH); // starts from 0 to 11
		int y = cal.get(Calendar.YEAR);

		// subtract birthday year from current year
		int age = y - this.year;
		// TO DO
		if (this.month > m + 1 || this.month == m + 1 && this.day > d) {
			age = age - 1;// or age--;
		}
		return age;
	}

}
