package words;

public class Main {

	public static void main(String[] args) {
		Words w = new Words();
		w.addWordsToArray("common_names.txt");
	}

}
